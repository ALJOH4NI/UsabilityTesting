import { useState } from "react";
import { Link } from "react-router-dom";
import AlertCompoent from "../AlertComponent";
import "./Login.scss";

const Login = () => {
  const studentUser = "student1@gmail.com"
  const tutorUser = "tutor1@gmail.com"
  const [userType,setUserType] = useState("");

  console.log("userType---->s " + userType)

  return (  
    <div className="center-panel" style={{ height: "70vh" }}>
      <main style={{ background: "#ececec" }}>
        <form>
          <h1 style={{ textAlign: "left" }}>Login</h1>
          <div className="form-field" style={{ width: "50%", marginLeft: "20%" }}>
            <label className="label--required">Email</label>
            <section>
              <input
                id="email"
                required
                type="email"
                placeholder="abc@gmail.com"
                onChange={(e)=>{
                  console.log(e.target.value)
                  setUserType(e.target.value)
                }}
                value={userType}
              />
            </section>
          </div>
          <div className="form-field" style={{ width: "68%", marginLeft: "20%" }}>
            <label className="label--required">Password</label>
            <section>
              <input
                id="phone"
                required
                type="password"
                placeholder="12345678"
              />
            </section>
            <Link to="/reset" style={{ marginLeft: "20px", color: "#47b0ba", fontWeight: "700" }}>Forgot password?</Link>
          </div>
          <div className="form-buttons" style={{ alignItems: "center" }} >
            {
              userType === studentUser ? 
              <Link  className="a-btn my-login-button" to="/studentDashbord">Login</Link>
              :
            <Link className="a-btn my-login-button" to="/tutorDashboard">Login</Link>
            }
          </div>
          Don't have an account? <Link to="/signup" style={{ marginLeft: "20px", color: "#47b0ba", fontWeight: "700" }}>Sign Up</Link>
        </form>
      </main>
    </div>
  );
};

export default Login;
