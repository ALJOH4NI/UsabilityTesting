import { Link } from 'react-router-dom';
import AvailableCourses  from '../../assets/courses/courses.json';

const SelectedCourses = () => {
  return (
    <div style={{ height: "80vh", marginTop: "80px" }}>
      <div className="row" style={{ height: "100%" }}>
        <div
          className="col-sm-2"
          style={{
            background: "lightgrey",
            height: "100%",
            display: "flex",
            flexDirection: "column",
            paddingTop: "40px",
          }}
        >
          <Link to="/profile">Profile</Link>
          <Link to="/selectedCourses">Selected Courses</Link>
          <Link to="/studentDashbord">Dashboard</Link>

        </div>
        <div className="col-sm-10" style={{ height: "100%" }}>
          <div className="row">
            <div
              className="col-sm-4"
              style={{ padding: "15px", marginBottom: "10px", height: "300px" }}
            >
               <div className="card" >
              
                
              <div className="align-center">
              <img src="/coursepic.png" className="card-img-top" style={{ width: "250px", marginTop: "20px"}}></img>
              
              {/* <img
                src="/user.jpeg"
                style={{ width: "80px", marginTop: "20px" }}
              />  */}

              </div>

              <div className="card-body">
                <h4 className="card-text">{"Mike"}</h4>
                <p className="card-title">{"Python"}</p>
                <p className="card-text">{"Learn A-Z everything about Python"}</p>
                <a href="#" className="btn btn-primary" >Contact Tutor</a>
              </div>
            </div>


            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SelectedCourses;
