import { Link } from 'react-router-dom';
import './Header.css';

function Header() {
  return (
    <>
    <header className="header row my-header">
    <div className="container" style={{display:"flex", width:"100%", justifyContent:"space-between"}}>
        <div className="logo" style={{marginTop: "4px", marginLeft: "30px"}}>
          <div style={{display:"flex"}}>
          <img src="/logo.png" style={{width: "100px",height: "70px"}} /> 
          <p className="heading-main">
          <p className="header-heading" style={{marginBottom:'0'}}>The easy way </p>
          <p className="header-heading">for learning computer science ourses</p>
          </p>
          </div>
        </div>
        <div>
        <a className="toggle-mobile-btn" href="javascript: void(0);">
        	<span></span>
        </a>
        <nav className="navigation">
        	<ul>
                <li><Link to="/login">Find Tutors</Link></li>
                <li><Link to="/signup">Become a Tutor</Link></li>
                <li><Link to="/signup">Sign up</Link></li>
                <li><Link to="/login">Log in</Link></li>
                <li><Link to="/"><img src="/logout.png" style={{width:"30px"}}/></Link></li>
                <li><Link to="/"><img src="/user(4).png" style={{width:"30px"}}/></Link></li>
            </ul>
        </nav>
        </div>
    </div>
</header>
    </>
  );
}

export default Header;
