import "./Footer.css";
import { library } from '@fortawesome/fontawesome-svg-core';
import { faAddressBook } from '@fortawesome/free-regular-svg-icons';

library.add(
    faAddressBook
);

function Footer() {
  return (
    <div className="app-footer">
      <header className="header row footer-marker">
        <div className="container">
          <div className="logo">
            <b>Follow us</b>
          </div>
          <a className="toggle-mobile-btn" href="javascript: void(0);">
            <span></span>
          </a>
          <nav className="navigation">
            <ul>
              <li>
                <a href="#">BANT</a>
              </li>
            </ul>
          </nav>
        </div>
      </header>
    </div>
  );
}

export default Footer;
