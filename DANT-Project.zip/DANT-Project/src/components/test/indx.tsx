function Resgitsration() {
  return (
    <div className="App">
      
    </div>
  );
}

export default Resgitsration;
