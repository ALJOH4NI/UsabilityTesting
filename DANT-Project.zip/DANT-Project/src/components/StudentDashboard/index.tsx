import { Link } from 'react-router-dom';
import AvailableCourses  from '../../assets/courses/courses.json';
import SelectedCourses  from '../../assets/courses/selectedCourses.json';


type CourseType = {
  "courseName": string,
  "courseDesc": string,
  "courseTutor": string

}
const StudentDashboard = () => {
  const addCourseToBasket = (course: CourseType) => {
    console.log("Add" + {course})
    SelectedCourses.selecctedDourses.push({course});
  }

  console.log(AvailableCourses)
  return (
    <div style={{ height: "80vh", marginTop: "80px" }}>
      <div className="row" style={{ height: "100%" }}>
        <div
          className="col-sm-2"
          style={{
            background: "#f5f5f5",
            height: "100%",
            display: "flex",
            flexDirection: "column",
            paddingTop: "40px",
          }}
        >
          <Link to="/profile">Profile</Link>
          <Link to="/selectedCourses">Selected Courses</Link>
          <Link to="/studentDashbord">Dashboard</Link>
          

        </div>
        <div className="col-sm-10" style={{ height: "100%" }}>
          <div className="row">
            {AvailableCourses.courses.map((course)=>{
           return <div
              className="col-sm-4"
              style={{ padding: "15px", marginBottom: "10px", height: "300px" }}
            >
              <div className="card" >
              
                
                <div className="align-center">
                <img src="/coursepic.png" className="card-img-top" style={{ width: "250px", marginTop: "20px"}}></img>
                
                {/* <img
                  src="/user.jpeg"
                  style={{ width: "80px", marginTop: "20px" }}
                />  */}

                </div>

                <div className="card-body">
                  <h4 className="card-text">{course.courseTutor}</h4>
                  <p className="card-title">{course.courseName}</p>
                  <p className="card-text">{course.courseDesc}</p>
                  <a href="/selectedCourses" className="btn btn-success" onClick={()=>addCourseToBasket(course)}>Add Tutor</a>
                </div>
              </div>
            </div>
            })}
          </div>
        </div>
      
      </div>
    </div>
  );
};

export default StudentDashboard;
