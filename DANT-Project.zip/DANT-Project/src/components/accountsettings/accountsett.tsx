import "./accountsett.scss";
import { Link } from 'react-router-dom';

const AccountSetting = () => {
  return (

    

    <div style={{ height: "80vh", marginTop: "80px" }}>
      <div className="row" style={{ height: "100%" }}>
        <div
          className="col-sm-2"
          style={{
            background: "#D9D9D9",
            height: "100%",
            display: "flex",
            flexDirection: "column",
            paddingTop: "40px",
          }}
        >
          <Link to="">Account</Link>
          <Link to="">Password</Link>
          <Link to="/studentDashbord">Dashboard</Link>

        </div>





        <div className="col-sm-10" style={{ height: "100%" }}>
          
           
          <div className="center-panel" style={{height:"70vh"}}>
      <main>
        <form>
          <h1>Account Settings</h1>
          <div className="form-field">
            <label className="label--required">Profile Image</label>
            <section>
              <input id="field" required type="file" style={{width:"300px"}} />
            </section>
          </div>
          <div className="form-field">
            <label className="label--required">First Name</label>
            <section>
              <input id="field" required type="text" placeholder="Jane" />
            </section>
          </div>
          <div className="form-field">
            <label className="label--required">Last Name</label>
            <section>
              <input id="field" required type="text" placeholder="Doe" />
            </section>
          </div>
          <div className="form-field">
            <label className="label--required">Phone Number</label>
            <section>
              <input id="field" required type="text" placeholder="123" />
            </section>
          </div>
          <div className="form-buttons">
            <button type="submit" className="a-btn--filled">
              Save Changes
            </button>
            <button type="submit" className="a-btn--filled">
              Delete account
            </button>
          </div>
        </form>
      </main>
    </div>
          



          </div>
        </div>
      
      </div>
     


  );
};

export default AccountSetting;
