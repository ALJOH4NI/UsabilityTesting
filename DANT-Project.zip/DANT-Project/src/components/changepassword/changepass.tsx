import "./changepass.scss";

const ChangePass = () => {
  return (
    <div className="center-panel" style={{ height: "70vh" }}>
      <main>
        <form>
          <h1>Reset</h1>
          <div className="form-field">
            <label className="label--required">Current Password</label>
            <section>
              <input
                id="phone"
                required
                type="password"
                placeholder="12345"
              />
            </section>
          </div>
          <div className="form-field">
            <label className="label--required">New Password</label>
            <section>
              <input
                id="phone"
                required
                type="password"
                placeholder="12345"
              />
            </section>
          </div>
          <div className="form-field">
            <label className="label--required">Verify Password</label>
            <section>
              <input
                id="phone"
                required
                type="password"
                placeholder="12345"
              />
            </section>
          </div>
          <div className="form-buttons">
            <button className="a-btn">Save Changes</button>
          </div>
        </form>
      </main>
    </div>
  );
};

export default ChangePass;
