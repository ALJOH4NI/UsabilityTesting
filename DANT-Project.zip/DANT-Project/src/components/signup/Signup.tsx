import { Link } from "react-router-dom";
import "./Signup.scss";

const SignUp = () => {
  return (
    <div className="center-panel" style={{ height: "70vh" }}>
      <main style={{background:"#ececec"}}>
        <form>
          <h1 style={{textAlign:"left"}}>Create an account!</h1>
          <div className="row">
            <div className="form-field col-sm-6">
              <label className="label--required">First Name</label>
              <section>
                <input id="field" required type="text" placeholder="Jane" />
              </section>
            </div>
            <div className="form-field col-sm-6">
              <label className="label--required">Last Name</label>
              <section>
                <input id="field" required type="text" placeholder="Doe" />
              </section>
            </div>
            <div className="form-field col-sm-6">
              <label className="label--required">Email</label>
              <section>
                <input
                  id="phone"
                  required
                  type="email"
                  placeholder="abc@gmail.com"
                />
              </section>
            </div>
            <div className="form-field col-sm-6">
              <label className="label--required">Role</label>
              <section style={{ paddingLeft: "20px" }}>
                <div className="form-check">
                  <input
                    className="form-check-input"
                    type="radio"
                    name="flexRadioDefault"
                    id="flexRadioDefault1"
                  />
                  <label className="form-check-label">Student</label>
                </div>
                <div className="form-check">
                  <input
                    className="form-check-input"
                    type="radio"
                    name="flexRadioDefault"
                    id="flexRadioDefault1"
                  />
                  <label className="form-check-label">Tutor</label>
                </div>
              </section>
            </div>
          </div>
          <div className="form-field">
            <label className="label--required">Password</label>
            <section>
              <input
                id="phone"
                required
                type="password"
                placeholder="12345678"
              />
            </section>
          </div>
          <div className="form-field">
            <label className="label--required">Confirm Password</label>
            <section>
              <input
                id="phone"
                required
                type="password"
                placeholder="12345678"
              />
            </section>
          </div>
          <div className="form-buttons" style={{alignItems:"center"}}>
            <Link className="a-btn my-login-button" to="/home">Sign Up</Link>
          </div>
          Already have an account? <Link to="/login" style={{marginLeft:"20px",color: "#47b0ba",fontWeight: "700"}}>Login In</Link>
        </form>
      </main>
    </div>
  );
};

export default SignUp;
