import "./Home.css";

const HomePage = () => {
  return (
    
    <div className="topPage" style={{height:"80vh"}}>
      <div className="row">
        <div className="col-sm-6 main-page-heading">
          <h1>Prepare yourself to be confident</h1>
          <h3>with the best online tutors</h3>
          <div
            className="col-md-8 offset-md-4 mt-5 "
            style={{ marginLeft: "20px" }}
          >
            <div className="input-group mb-3">
              <input
                type="text"
                className="form-control"
                placeholder="Search for tutors"
                aria-label="Recipient's username"
              />
              <div className="input-group-append">
                <span className="input-group-text">Explore By Tutor</span>
              </div>
            </div>
          </div>
        </div>

       
        <div className="col-sm-6" style={{ display: "flex" }}>
          <img src="/banner.PNG" style={{ width: "500px" }} />
        </div>

        {/* <div
          className="col-sm-4"
          style={{ padding: "15px", marginBottom: "10px", height: "300px" }}
        >
          <div style={{ background: "lightgrey", width:"100%", height:"100%" }}>
              <img src="/user.jpeg" style={{width: "80px",marginTop: "20px"}}/>
              <h1 style={{color:"black"}}>User 1</h1>
              <h4 style={{color:"white"}}>*****</h4>
              <p style={{color:"blue"}}>description goes here</p>
          </div> */}

        </div>
        {/* <div
          className="col-sm-4"
          style={{ padding: "15px", marginBottom: "10px", height: "300px" }}
        >
          <div style={{ background: "lightgrey", width:"100%", height:"100%" }}>
          <div style={{ background: "lightgrey", width:"100%", height:"100%" }}>
              <img src="/user.jpeg" style={{width: "80px",marginTop: "20px"}}/>
              <h1 style={{color:"black"}}>User 1</h1>
              <h4 style={{color:"white"}}>*****</h4>
              <p style={{color:"blue"}}>description goes here</p>
          </div>
          </div>
        </div> */}
        {/* <div
          className="col-sm-4"
          style={{ padding: "15px", marginBottom: "10px", height: "300px" }}
        >
          <div style={{ background: "lightgrey", width:"100%", height:"100%" }}>
          <div style={{ background: "lightgrey", width:"100%", height:"100%" }}>
              <img src="/user.jpeg" style={{width: "80px",marginTop: "20px"}}/>
              <h1 style={{color:"black"}}>User 1</h1>
              <h4 style={{color:"white"}}>*****</h4>
              <p style={{color:"blue"}}>description goes here</p>
          </div>
          </div>
        </div> */}
      </div>
  
  );
};

export default HomePage;
