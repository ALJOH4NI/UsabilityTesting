import "./courses.scss";

const Courses = () => {
  return (
    <div style={{ height: "80vh", marginTop: "80px" }}>
      <div className="row" style={{ height: "100%" }}>
        <div
          className="col-sm-2"
          style={{
            background: "lightgrey",
            height: "100%",
            display: "flex",
            flexDirection: "column",
            paddingTop: "40px",
          }}
        >
          <h6 style={{ color: "blue" }}>Profile</h6>
          <h6 style={{ color: "blue" }}>Selected Courses</h6>
          <h6 style={{ color: "blue" }}>Find a Tutor</h6>
          <h6 style={{ color: "blue" }}>Dashboard</h6>
        </div>
        <div className="col-sm-10" style={{ height: "100%" }}>
          <div className="row">
            <div
              className="col-sm-4"
              style={{ padding: "15px", marginBottom: "10px", height: "300px" }}
            >
              <div
                style={{
                  background: "lightgrey",
                  width: "100%",
                  height: "100%",
                }}
              >
                <img
                  src="/user.jpeg"
                  style={{ width: "80px", marginTop: "20px" }}
                />
                <h1 style={{ color: "black" }}>Databases</h1>
                <h4 style={{ color: "white" }}>*****</h4>
                <p style={{ color: "blue" }}>description goes here</p>
              </div>
            </div>
            <div
              className="col-sm-4"
              style={{ padding: "15px", marginBottom: "10px", height: "300px" }}
            >
              <div
                style={{
                  background: "lightgrey",
                  width: "100%",
                  height: "100%",
                }}
              >
                <div
                  style={{
                    background: "lightgrey",
                    width: "100%",
                    height: "100%",
                  }}
                >
                  <img
                    src="/user.jpeg"
                    style={{ width: "80px", marginTop: "20px" }}
                  />
                  <h4 style={{ color: "black" }}>Mr. Ahmed</h4>
                  <h3 style={{ color: "white" }}>Data Structure</h3>
                  <p style={{ color: "blue" }}>description goes here</p>
                </div>
              </div>
            </div>
            <div
              className="col-sm-4"
              style={{ padding: "15px", marginBottom: "10px", height: "300px" }}
            >
              <div
                style={{
                  background: "lightgrey",
                  width: "100%",
                  height: "100%",
                }}
              >
                <div
                  style={{
                    background: "lightgrey",
                    width: "100%",
                    height: "100%",
                  }}
                >
                  <img
                    src="/user.jpeg"
                    style={{ width: "80px", marginTop: "20px" }}
                  />
                  <h1 style={{ color: "black" }}>Data Mining</h1>
                  <h4 style={{ color: "white" }}>*****</h4>
                  <p style={{ color: "blue" }}>description goes here</p>
                </div>
              </div>
            </div>
            <div
              className="col-sm-4"
              style={{ padding: "15px", marginBottom: "10px", height: "300px" }}
            >
              <div
                style={{
                  background: "lightgrey",
                  width: "100%",
                  height: "100%",
                }}
              >
                <img
                  src="/user.jpeg"
                  style={{ width: "80px", marginTop: "20px" }}
                />
                <h1 style={{ color: "black" }}>Math</h1>
                <h4 style={{ color: "white" }}>*****</h4>
                <p style={{ color: "blue" }}>description goes here</p>
              </div>
            </div>
            <div
              className="col-sm-4"
              style={{ padding: "15px", marginBottom: "10px", height: "300px" }}
            >
              <div
                style={{
                  background: "lightgrey",
                  width: "100%",
                  height: "100%",
                }}
              >
                <div
                  style={{
                    background: "lightgrey",
                    width: "100%",
                    height: "100%",
                  }}
                >
                  <img
                    src="/user.jpeg"
                    style={{ width: "80px", marginTop: "20px" }}
                  />
                  <h1 style={{ color: "black" }}>Java</h1>
                  <h4 style={{ color: "white" }}>*****</h4>
                  <p style={{ color: "blue" }}>description goes here</p>
                </div>
              </div>
            </div>
            <div
              className="col-sm-4"
              style={{ padding: "15px", marginBottom: "10px", height: "300px" }}
            >
              <div
                style={{
                  background: "lightgrey",
                  width: "100%",
                  height: "100%",
                }}
              >
                <div
                  style={{
                    background: "lightgrey",
                    width: "100%",
                    height: "100%",
                  }}
                >
                  <img
                    src="/user.jpeg"
                    style={{ width: "80px", marginTop: "20px" }}
                  />
                  <h1 style={{ color: "black" }}>Python</h1>
                  <h4 style={{ color: "white" }}>*****</h4>
                  <p style={{ color: "blue" }}>description goes here</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Courses;
