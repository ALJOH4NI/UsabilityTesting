import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Header from "./components/header/Header";
import Footer from "./components/footer/Footer";
import SignUp from "./components/signup/Signup";
import Login from "./components/login/Login";
import HomePage from "./components/homepage/Home";
import ChangePass from "./components/changepassword/changepass";
import AccountSetting from "./components/accountsettings/accountsett";
import Courses from "./components/courses/courses";
import StudentDashboard from "./components/StudentDashboard";
import SelectedCourses from "./components/SelectedCourses/seledctedCourses";
import TutorDashboard from "./components/TutorDashboard";
import Resgitsration from "./components/test/indx";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Header />
        <Routes>
          <Route path="/signup" element={<SignUp />} />
          <Route path="/login" element={<Login />} />
          <Route path="/" element={<HomePage />} />
          <Route path="/reset" element={<ChangePass />} />
          <Route path="/profile" element={<AccountSetting />} />
          <Route path="/courses" element={<Courses />} />
          <Route path="/studentDashbord" element={<StudentDashboard />} />
          <Route path="/tutorDashboard" element={<TutorDashboard />} />
          <Route path="/selectedCourses" element={<SelectedCourses />} />

          <Route path="/rrrr" element={<Resgitsration/>} />          
        </Routes>
        <Footer />
      </BrowserRouter>
    </div>
  );
}

export default App;
